<?php include 'connection.php';?>
<html>
    <head>

</head>
<body>
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Position</th>
                                            <th>Office</th>
                                            <th>Age</th>
                                            <th>Start date</th>
                                            <th>Salary</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Name</th>
                                            <th>Position</th>
                                            <th>Office</th>
                                            <th>Age</th>
                                            <th>Start date</th>
                                            <th>Salary</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
<?php
echo $strQuery="select * from posts";
$res=mysqli_query($con,$strQuery);
while($row=mysqli_fetch_assoc($res)){
?>
                                        <tr>
                                            <td><?php echo $row['ID'];?></td>
                                            <td><?php echo $row['title'];?></td>
                                            <td><?php echo $row['description'];?></td>
                                            <td>21</td>
                                            <td>2011/04/25</td>
                                            <td>$320,800</td>
                                            <td>
											  <a  class="btn btn-danger" onclick="deleteRecord(<?php echo $row['ID'];?>)" href="javascript:void(0)">DELETE</a></td>
                                        </tr>
    <?php } ?>                                   
                                    </tbody>
                                </table>
                                <script>
					function deleteRecord(id)
					{
                       
						var x=confirm("do you want to Delete?")
						if(x==true)
						{
							window.location="post_delete.php?did="+id;
						}
						
					}
	</script>
                                </body>


</html>
