<?php 
	$did=$_REQUEST['did'];
	include('connection.php');
	mysqli_query($con,"delete from posts where id='$did' ");
   // echo $id=mysqli_affected_rows($con);
    //var_dump($id);die('test');
	if(mysqli_affected_rows($con)==1)
	{
		header("location:posts.php?delete=1");
	}


?>
