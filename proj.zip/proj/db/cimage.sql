
INSERT INTO `admin1` (`username`, `password`) VALUES
('admin', 'admin'),
('admin1', 'admin1'),
('hello', 'hello'),
('cimage', 'cimage');

-- --------------------------------------------------------

--
-- Table structure for table `admin2`
--

CREATE TABLE `admin2` (
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin2`
--

INSERT INTO `admin2` (`username`, `password`) VALUES
('admin', 'admin'),
('cimage', 'cimage'),
('hello', 'hello'),
('local', 'local');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `ID` int(11) NOT NULL,
  `OrderNumber` varchar(30) DEFAULT NULL,
  `OrderDate` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `ID` int(11) NOT NULL,
  `title` varchar(30) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_ated` date DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`ID`, `title`, `description`, `created_ated`, `date_updated`) VALUES
(5, 'News India', 'b', NULL, NULL),
(6, 'A', 'b', NULL, NULL),
(7, 'A', 'b', NULL, NULL),
(8, 'A', 'b', NULL, NULL),
(9, 'Hello News', 'Welcome back', NULL, NULL),
(10, 'Hello ', 'Welcome', NULL, NULL),
(11, NULL, NULL, '2012-01-01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `soc`
--

CREATE TABLE `soc` (
  `ID` int(11) NOT NULL,
  `dob` date DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `soc`
--

INSERT INTO `soc` (`ID`, `dob`, `start_date`, `end_date`) VALUES
(1, '2020-02-02', NULL, '2023-03-12 14:48:24'),
(2, '2001-03-03', '2001-03-03 10:10:10', '2001-03-03 05:41:11');

-- --------------------------------------------------------

--
-- Table structure for table `times`
--

CREATE TABLE `times` (
  `CREATED` date DEFAULT NULL,
  `UPDATED` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `times`
--

INSERT INTO `times` (`CREATED`, `UPDATED`) VALUES
('2023-03-23', '2023-03-30 10:16:56'),
('2023-03-29', '2023-03-29 10:19:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;


