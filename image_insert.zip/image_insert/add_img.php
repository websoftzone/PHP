<?php
$con=mysqli_connect("localhost","root","","cimage");
if(!empty($_REQUEST['title']) && !empty($_REQUEST['dscr'])){
$title=$_REQUEST['title'];
$descr=$_REQUEST['dscr'];

# image upload code 
$img_name=$_FILES['img']['name'];
 $tmp_name=$_FILES['img']['tmp_name'];
 $target="profile/".$img_name;
 move_uploaded_file($tmp_name,$target);

#end image upload code
$query="INSERT into pages(title,description,path) values('$title','$descr','$target')";
$rs=mysqli_query($con,$query);
if($rs){

    echo "Record Added Successfully";
}else{
    echo "Failed to add record";
}

}
?>
<form method="post" enctype="multipart/form-data">
Title: <input type="text" name="title"><br><br>
Description:<textarea name="dscr" cols="25" rows="5"></textarea><br><br>
<input type="file" name="img" /><br><br>
<input  style="font-family:arial,Helvetica,sans-serif" type="submit" name="submit" value="Add Page">
</form>

